ULAB — LOCAL RELEASE V1.0.0
============================

WHAT THIS RELEASE DOES
----------------------
ULAB connects supported AI web applications to a local, sandboxed agent.
The agent runs on this computer and exposes only the selected workspace.

FIRST INSTALL
-------------
1. Run Install-ULAB.bat.
2. Open Chrome when the installer finishes.
3. Go to chrome://extensions/ and enable Developer mode.
4. Choose Load unpacked and select:
   %LOCALAPPDATA%\ULAB\extension
5. Start %LOCALAPPDATA%\ULAB\Start-ULAB-Agent.bat.
6. Open the ULAB side panel from the Chrome toolbar.
7. Use the displayed local Agent URL and Security Token.
8. Click Save Connection, then Connect Agent.
9. Select the project/workspace you want ULAB to operate on.

NORMAL USE
----------
Start %LOCALAPPDATA%\ULAB\Start-ULAB-Agent.bat before using ULAB.
The local security token is persisted in the current Windows user profile,
so restarting the agent does not normally require a new token.

SECURITY MODEL
--------------
- Agent listens on 127.0.0.1 only.
- WebSocket RPC requires the local security token.
- Extension connections are restricted to localhost:19999.
- Workspace paths are sandboxed by the agent.
- Sensitive files are excluded by policy.
- File writes/deletes and risky terminal operations require approval.
- Sessions are invalidated when the active workspace changes.
- Audit records track important operations and redact secrets.

PRIVACY
-------
ULAB is local-first. Project files are accessed by the local agent only
inside the selected workspace. Remote Desktop Commander access remains
restricted to the ULAB project directory during development.

TROUBLESHOOTING
---------------
If the side panel says the agent is offline, make sure Start-ULAB-Agent.bat
is running and that the URL is ws://127.0.0.1:19999.
If Chrome rejects the extension, reload it from chrome://extensions/.
If the token is lost, stop the agent, remove the local agent.token file,
and start the agent again to generate a new token.

DEVELOPMENT
-----------
Source: C:\Users\PC\ulab
Web build: npm run build
Agent build: cd agent && npm run build
Windows package: cd agent && npm run package
